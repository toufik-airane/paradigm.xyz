---
'openzeppelin-solidity': patch
---

`Governor`: Add validation in ERC1155 and ERC721 receiver hooks to ensure Governor is the executor.

