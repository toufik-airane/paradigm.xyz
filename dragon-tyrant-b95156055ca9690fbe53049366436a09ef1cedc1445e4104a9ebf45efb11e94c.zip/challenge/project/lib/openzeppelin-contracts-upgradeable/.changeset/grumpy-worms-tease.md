---
'openzeppelin-solidity': major
---

`ERC1967Utils`: Refactor the `ERC1967Upgrade` abstract contract as a library.
