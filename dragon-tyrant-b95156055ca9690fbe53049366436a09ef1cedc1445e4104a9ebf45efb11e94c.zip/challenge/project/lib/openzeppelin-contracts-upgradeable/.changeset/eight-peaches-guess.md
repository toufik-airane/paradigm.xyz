---
'openzeppelin-solidity': minor
---

`Proxy`: Removed redundant `receive` function.
