---
'openzeppelin-solidity': minor
---

`EIP712`: Add internal getters for the name and version strings
