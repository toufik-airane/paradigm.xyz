---
'openzeppelin-solidity': minor
---

`Arrays`: Add `unsafeMemoryAccess` helpers to read from a memory array without checking the length.
