---
'openzeppelin-solidity': patch
---

`Governor`: Add a mechanism to restrict the address of the proposer using a suffix in the description.
