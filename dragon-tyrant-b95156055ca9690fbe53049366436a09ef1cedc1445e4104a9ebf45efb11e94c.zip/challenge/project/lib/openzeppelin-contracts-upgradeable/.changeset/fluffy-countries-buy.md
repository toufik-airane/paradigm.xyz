---
'openzeppelin-solidity': minor
---

`Arrays`: Optimize `findUpperBound` by removing redundant SLOAD.
