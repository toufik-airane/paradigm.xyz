---
'openzeppelin-solidity': major
---

`Checkpoints`: library moved from `utils` to `utils/structs`
