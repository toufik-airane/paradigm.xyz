---
'openzeppelin-solidity': major
---

Bump minimum compiler version required to 0.8.19
