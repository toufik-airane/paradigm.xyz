---
'openzeppelin-solidity': patch
---

Optimize `Strings.equal`
