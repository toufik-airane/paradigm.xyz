---
'openzeppelin-solidity': major
---

`Strings`: Rename `toString(int256)` to `toStringSigned(int256)`.
