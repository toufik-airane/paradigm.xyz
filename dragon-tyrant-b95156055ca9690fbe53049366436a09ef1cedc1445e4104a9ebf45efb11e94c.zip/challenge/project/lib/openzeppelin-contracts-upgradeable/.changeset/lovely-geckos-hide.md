---
'openzeppelin-solidity': major
---

Replace revert strings and require statements with custom errors.
