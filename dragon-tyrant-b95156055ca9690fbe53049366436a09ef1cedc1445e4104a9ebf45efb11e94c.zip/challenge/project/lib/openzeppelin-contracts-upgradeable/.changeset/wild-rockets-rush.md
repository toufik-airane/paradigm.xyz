---
'openzeppelin-solidity': major
---

`Math`: Renamed members of `Rounding` enum, and added a new rounding mode for "away from zero".
