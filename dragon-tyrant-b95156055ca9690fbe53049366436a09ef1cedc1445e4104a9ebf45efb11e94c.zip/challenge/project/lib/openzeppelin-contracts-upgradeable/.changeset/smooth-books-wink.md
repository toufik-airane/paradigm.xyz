---
'openzeppelin-solidity': major
---

`ERC1155`: Remove check for address zero in `balanceOf`.
