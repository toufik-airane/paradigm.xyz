---
'openzeppelin-solidity': major
---

`Ownable`: Add an `initialOwner` parameter to the constructor, making the ownership initialization explicit.
