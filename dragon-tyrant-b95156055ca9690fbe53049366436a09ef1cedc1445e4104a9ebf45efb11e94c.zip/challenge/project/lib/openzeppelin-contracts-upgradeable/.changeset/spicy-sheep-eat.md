---
'openzeppelin-solidity': major
---

`access`: Move `AccessControl` extensions to a dedicated directory.
