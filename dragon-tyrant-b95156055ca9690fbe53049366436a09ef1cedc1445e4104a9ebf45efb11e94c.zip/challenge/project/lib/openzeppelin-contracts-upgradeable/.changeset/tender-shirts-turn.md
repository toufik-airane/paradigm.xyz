---
'openzeppelin-solidity': major
---

`BeaconProxy`: Reject value in initialization unless a payable function is explicitly invoked.
