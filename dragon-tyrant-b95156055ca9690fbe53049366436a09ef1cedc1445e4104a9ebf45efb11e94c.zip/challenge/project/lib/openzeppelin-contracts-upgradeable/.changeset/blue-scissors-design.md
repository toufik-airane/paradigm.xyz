---
'openzeppelin-solidity': minor
---

`Math`: Make `ceilDiv` to revert on 0 division even if the numerator is 0
