---
'openzeppelin-solidity': minor
---

`TimelockController`: Add a state getter that returns an `OperationState` enum.
