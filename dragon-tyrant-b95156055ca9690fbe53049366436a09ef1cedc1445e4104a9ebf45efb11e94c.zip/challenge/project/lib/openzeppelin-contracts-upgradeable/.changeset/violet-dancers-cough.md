---
'openzeppelin-solidity': minor
---

Remove the `override` specifier from functions that only override a single interface function.
