---
'openzeppelin-solidity': major
---

`ERC1155Receiver`: Removed in favor of `ERC1155Holder`.
