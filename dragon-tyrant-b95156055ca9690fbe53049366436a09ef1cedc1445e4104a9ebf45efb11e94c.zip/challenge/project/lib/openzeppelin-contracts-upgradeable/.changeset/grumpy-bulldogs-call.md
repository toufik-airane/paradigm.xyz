---
'openzeppelin-solidity': major
---

`Governor`: Optimized use of storage for proposal data
