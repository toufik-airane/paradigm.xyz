---
'openzeppelin-solidity': patch
---

`ERC1155`: Optimize array allocation.
