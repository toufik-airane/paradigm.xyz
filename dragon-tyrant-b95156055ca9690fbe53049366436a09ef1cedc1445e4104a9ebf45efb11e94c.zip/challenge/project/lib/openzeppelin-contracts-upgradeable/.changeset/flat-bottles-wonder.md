---
'openzeppelin-solidity': minor
---

Replace some uses of `abi.encodePacked` with clearer alternatives (e.g. `bytes.concat`, `string.concat`).
