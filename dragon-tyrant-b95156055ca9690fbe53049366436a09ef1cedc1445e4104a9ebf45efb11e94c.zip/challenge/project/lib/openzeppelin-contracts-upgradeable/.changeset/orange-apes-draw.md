---
'openzeppelin-solidity': major
---

Switched to using explicit Solidity import statements. Some previously available symbols may now have to be separately imported.
