---
'openzeppelin-solidity': minor
---

`GovernorTimelockControl`: Clean up timelock id on execution for gas refund.
