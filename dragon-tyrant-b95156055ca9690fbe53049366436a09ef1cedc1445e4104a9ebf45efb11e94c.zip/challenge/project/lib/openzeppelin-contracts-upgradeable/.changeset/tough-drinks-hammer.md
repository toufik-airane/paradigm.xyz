---
'openzeppelin-solidity': patch
---

`ERC1155`: Optimize array accesses by skipping bounds checking when unnecessary.
