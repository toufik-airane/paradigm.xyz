#!/bin/sh

cd framework-solve && cargo r --release
