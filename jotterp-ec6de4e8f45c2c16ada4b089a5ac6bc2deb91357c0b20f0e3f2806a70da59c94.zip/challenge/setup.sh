#!/bin/sh

curl https://run.osec.io/solana | sh
